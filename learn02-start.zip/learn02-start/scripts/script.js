function myfunction2() {
    document.getElementById("sample").innetHTML = "Changed from the function in the head setion"
}