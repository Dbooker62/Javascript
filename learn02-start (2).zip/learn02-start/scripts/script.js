function myfunction2() {
    document.getElementById("sample").innerHTML = "Changed from the function in the outer setion";
}