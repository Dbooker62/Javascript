package com.example.recyclerview.models

class Mymodel {
    var iconsCard: Int?
    var textCard: String?

    constructor(iconsCard: Int, textCard: String?)
    {
        this.iconsCard = iconsCard
        this.textCard = textCard
    }
}